'use strict';
var bindArea, bindAutocomplete, bindCardMinimizer, bindControlFocusEvent, bindDatepicker, bindDropdown, bindFilepicker, bindPopup, bindPseudoLinkNavigation, bindSidebarButton, bindStatisticsSidebar, bindTabs, bindTimepicker, bindedDatepickers, checkPopupScroll, confirmAction, detectIe, initControlsSets, initRating, initTextareaAutosize, showLastAddNewOptionBtn, showLastAddNewOptionBtnGroup, showPopup, toggleProgress, unbindEvents;

$(function() {
    initTextareaAutosize();
    bindControlFocusEvent();
    bindPopup();
    bindFilepicker();
    bindTabs();
    bindSidebarButton();
    bindStatisticsSidebar();
    initRating();
    bindCardMinimizer();
    bindDropdown();
    detectIe();
    initControlsSets();
    bindPseudoLinkNavigation();
    bindDatepicker();
    bindArea();
    bindTimepicker();
    return bindAutocomplete();
});

checkPopupScroll = function() {
    var $activePopupBody, scrollClass;
    $activePopupBody = $('.popup_active').find('.popup__body');
    scrollClass = 'popup_scroll';
    if (!$activePopupBody.length) {
        return;
    }
    if (Math.ceil($activePopupBody.scrollTop()) + Math.ceil($activePopupBody.innerHeight()) >= Math.ceil($activePopupBody[0].scrollHeight)) {
        return $activePopupBody.closest('.popup').removeClass(scrollClass);
    } else {
        return $activePopupBody.closest('.popup').addClass(scrollClass);
    }
};

initTextareaAutosize = function() {};

bindControlFocusEvent = function() {
    return $('.control__box').focus(function() {
        return $(this).closest('.control').removeClass('control_invalid');
    });
};

showPopup = function($targetPopup) {
    if ($targetPopup.length) {
        $targetPopup.fadeIn().css('display', 'flex');
        $('body').addClass('no-scroll');
        return setTimeout(function() {
            $targetPopup.addClass('popup_active');
            $targetPopup.find('.control__box:first').not('.datepicker__input').focus();
            $targetPopup.scrollTop(0);
            return checkPopupScroll();
        }, 100);
    }
};

bindPopup = function() {
    var $body, $button, $popup, activeClass, changedFormClass, closePopup, noScrollClass, untargetableClass;
    $popup = $('.popup');
    $button = $('[data-popup]');
    activeClass = 'popup_active';
    $body = $('body');
    noScrollClass = 'no-scroll';
    changedFormClass = 'changed-form';
    untargetableClass = 'js--popup-untargetable';
    unbindEvents([$popup, $button, $('[data-table-popup]'), $('.popup__content'), $('.popup__body')]);
    closePopup = function($targetPopup) {
        $targetPopup.removeClass(activeClass).fadeOut();
        return $body.removeClass(noScrollClass);
    };
    $popup.click(function(e) {
        var $form, $target, $targetPopup;
        $target = $(e.target);
        $targetPopup = $(this);
        if ((!$target.closest('.popup__content').length || $target.is('.js--popup-close')) && (!$target.is('.set__delete')) && (!$target.is('.area__delete'))) {
            $form = $targetPopup.find('.popup__content');
            if ($targetPopup.hasClass('confirmation')) {
                closePopup($targetPopup);
                return $form.removeClass(changedFormClass);
            } else if ($form.hasClass(changedFormClass)) {
                return confirmAction(function() {
                    closePopup($targetPopup);
                    return $form.removeClass(changedFormClass);
                }, 'Close?', 'Yes');
            } else {
                closePopup($targetPopup);
                return $form.removeClass(changedFormClass);
            }
        }
    });
    $button.click(function(e) {
        e.preventDefault();
        return showPopup($("#" + ($(this).data('popup'))));
    });
    $('[data-table-popup]').click(function(e) {
        var $target;
        $target = $(e.target);
        if (!$target.hasClass(untargetableClass) && !$target.closest("." + untargetableClass).length) {
            return showPopup($("#" + ($(this).data('table-popup'))));
        }
    });
    $('.popup__content').change(function() {
        return $(this).addClass(changedFormClass);
    });
    $('.popup__body').scroll(function() {
        return checkPopupScroll();
    });
    return $(window).resize(function() {
        return checkPopupScroll();
    });
};

bindFilepicker = function() {
    var $fileInput, $textInput, FILE_SIZE;
    $textInput = $('.filepicker__input');
    $fileInput = $('.filepicker__file');
    FILE_SIZE = 10;
    unbindEvents([$textInput, $fileInput]);
    $fileInput.change(function() {
        $(this).closest('.control').removeClass('control_invalid');
        if (this.files.length) {
            if (this.files[0].size / 1024 / 1024 > FILE_SIZE) {
                $(this).closest('.control').addClass('control_invalid');
                return $(this).replaceWith($(this).val('').clone(true));
            } else {
                return $(this).siblings($textInput).val($(this)[0].files[0].name);
            }
        }
    });
    return $textInput.focus(function() {
        return false;
    });
};

bindTabs = function() {
    var $switcherButton, $tab, activeLinkClass, changeTab, firstHash;
    $tab = $('.tabs__tab');
    $switcherButton = $('.js--tab-switcher');
    activeLinkClass = 'switcher__link_active';
    changeTab = function() {
        var hash;
        hash = location.hash;
        if ($(hash).is('.tabs__tab')) {
            $tab.css('display', 'none');
            $switcherButton.removeClass(activeLinkClass);
            $(hash).fadeIn();
            return $(".switcher__link[href='" + hash + "']").addClass(activeLinkClass);
        }
    };
    if (!$(location.hash).is('.tabs__tab')) {
        firstHash = $tab.first().attr('id');
        if (firstHash) {
            location.hash = firstHash;
        }
    } else {
        changeTab();
    }
    $switcherButton.click(function(e) {
        var $targetTab, tabHash;
        e.preventDefault();
        tabHash = $(this).attr('href');
        $targetTab = $(tabHash);
        if (!$targetTab.is(':visible')) {
            return location.hash = tabHash;
        }
    });
    return $(window).on('hashchange', function() {
        return changeTab();
    });
};

bindSidebarButton = function() {
    var $button, $sidebar, activeClass;
    $sidebar = $('.sidebar');
    $button = $('.sidebar-button');
    activeClass = 'sidebar_active';
    $button.click(function() {
        return $sidebar.addClass(activeClass);
    });
    return $(document).click(function(e) {
        var $target;
        $target = $(e.target);
        if ((!$target.closest($sidebar).length && !$target.closest($button).length && window.innerWidth <= 600) || $target.is('.sidebar__close')) {
            return $sidebar.removeClass(activeClass);
        }
    });
};

toggleProgress = function(action) {
    return $('.progress').each(function() {
        return $(this).find('.progress__connect').css('width', (action > 0 ? $(this).data('percent') : 0) + "%");
    });
};

bindStatisticsSidebar = function() {
    var $button, $closeButton, $page, action, activeButtonClass, activePageClass, toggleSidebar;
    $button = $('#stats-button');
    $page = $('.page');
    $closeButton = $('.statistics__close');
    activePageClass = 'page_stats';
    activeButtonClass = 'tool_active';
    action = {
        hide: 0,
        toggle: 1
    };
    toggleSidebar = function(type) {
        switch (type) {
            case action.hide:
                $page.removeClass(activePageClass);
                $button.removeClass(activeButtonClass);
                return toggleProgress(-1);
            case action.toggle:
                $page.toggleClass(activePageClass);
                $(this).toggleClass(activeButtonClass);
                if ($page.hasClass(activePageClass)) {
                    return toggleProgress(1);
                } else {
                    return toggleProgress(-1);
                }
        }
    };
    $button.click(function() {
        return toggleSidebar(action.toggle);
    });
    $closeButton.click(function() {
        return toggleSidebar(action.hide);
    });
    return $(document).click(function(e) {
        var $target;
        $target = $(e.target);
        if ((!$target.closest('.statistics').length && !$target.closest($button).length && window.innerWidth <= 800) || $target.is($closeButton)) {
            return toggleSidebar(action.hide);
        }
    });
};

initRating = function() {
    return $('.rating').each(function() {
        var $star, counter, interval, value;
        value = $(this).data('value');
        if (value > 0 && value <= 5) {
            counter = 0;
            $star = $(this).find('.rating__star');
            return interval = setInterval(function() {
                if (counter >= value) {
                    clearInterval(interval);
                    return false;
                }
                return $($star.eq(counter++)).addClass('rating__star_active');
            }, 200);
        }
    });
};

bindCardMinimizer = function() {
    var $minimizer;
    $minimizer = $('.card__minimizer');
    unbindEvents([$minimizer]);
    return $('.card__minimizer').click(function() {
        return $(this).closest('.card').find('.card__body').slideToggle(function() {
            return $(this).closest('.card').toggleClass('card_hidden');
        });
    });
};

bindDropdown = function() {
    var $dropdowns, activeClass, selected;
    activeClass = 'dropdown_active';
    selected = 'data-selected';
    $dropdowns = $('.dropdown');
    $dropdowns.each(function() {
        var $button, $closestTable, $dropdown, $item, $list, index, setOption;
        $dropdown = $(this);
        $button = $dropdown.find('.dropdown__button');
        $list = $dropdown.find('.dropdown__list');
        $item = $dropdown.find('.dropdown__item');
        $closestTable = $dropdown.closest('.table');
        unbindEvents([$dropdown, $button]);
        setOption = function(index) {
            var $option;
            $option = $($item.eq(index));
            $item.removeAttr(selected);
            $option.attr(selected, '');
            $button.text($option.text());
            $button.attr('data-color', $option.data('color'));
            $dropdown.removeClass(activeClass);
            $dropdown.attr('data-value', $option.data('value'));
            return $closestTable.css('padding-bottom', '');
        };
        $button.click(function() {
            $dropdown.addClass(activeClass);
            if ((($closestTable.find($dropdowns).index($dropdown) === ($dropdowns.length - 1)) && (!$closestTable.find('.table__footer').length)) || ($closestTable.find($dropdown).length === 1)) {
                return $closestTable.css('padding-bottom', $list.height());
            }
        });
        $item.click(function() {
            return setOption($item.index($(this)));
        });
        index = $item.index($dropdown.find("[" + selected + "]"));
        return setOption(index >= 0 ? index : 0);
    });
    return $(document).click(function(e) {
        var $closestDropdown;
        $closestDropdown = $(e.target).closest($dropdowns);
        if (!$closestDropdown.length) {
            $dropdowns.removeClass(activeClass);
            return $('.table').css('padding-bottom', '');
        } else {
            return $dropdowns.not($closestDropdown).removeClass(activeClass);
        }
    });
};

detectIe = function() {
    var $html, ie, userAgent;
    userAgent = window.navigator.userAgent;
    $html = $('html');
    ie = (userAgent.indexOf('MSIE ')) > 0 || (userAgent.indexOf('Trident/') >= 0);
    if (ie) {
        $html.addClass('ie');
    }
    if ((userAgent.indexOf('MSIE 10')) >= 0) {
        return $html.addClass('ie10');
    }
};

initControlsSets = function() {
    var $set, addButtonTemplate, bindEvents, deleteButtonTemplate, recalculateNameIndexes, setControl, setItem;
    $set = $('.set');
    setItem = '.set__item';
    setControl = '.set__control';
    addButtonTemplate = "<span class='set__button set__add link icon_plus'></span>";
    deleteButtonTemplate = "<span class='set__button set__delete link icon_trash'></span>";
    unbindEvents([$set]);
    recalculateNameIndexes = function($set) {
        var index;
        index = 1;
        return $set.find(setControl).each(function() {
            return $(this).attr('name', ($(this).attr('name').split('__')[0]) + "__" + (index++));
        });
    };
    bindEvents = function() {
        return $('.set').each(function() {
            var $sampleItem;
            $set = $(this);
            $sampleItem = $(this).find(setItem).first();
            $sampleItem.append(addButtonTemplate);
            $(this).find(setItem).not($sampleItem).append(deleteButtonTemplate);
            $(this).on('click', '.set__add', function() {
                var $controlCopy, $itemCopy;
                $itemCopy = $sampleItem.clone(true, true);
                $controlCopy = $itemCopy.find(setControl);
                $controlCopy.val('');
                $itemCopy.find('.control__mark').find('.checkbox__input').prop('checked', false);
                if ($controlCopy.is('.filepicker__file')) {
                    $controlCopy.siblings('.filepicker__input').val('');
                    $controlCopy.replaceWith($controlCopy.val('').clone(true));
                }
                $itemCopy.find('.set__add').remove();
                $itemCopy.append(deleteButtonTemplate);
                $set.append($itemCopy);
                recalculateNameIndexes($set);
                return checkPopupScroll();
            });
            return $(this).on('click', '.set__delete', function() {
                $set = $(this).closest('.set');
                $(this).closest(setItem).remove();
                recalculateNameIndexes($set);
                return checkPopupScroll();
            });
        });
    };
    return bindEvents();
};

bindPseudoLinkNavigation = function() {
    var $pseudoLink;
    $pseudoLink = $('[data-href]');
    unbindEvents([$pseudoLink]);
    return $pseudoLink.click(function(e) {
        var $target, url;
        $target = $(e.target);
        if ($target.is('tr') || $target.is('td')) {
            url = $(this).data('href');
            if (url.length) {
                return location.href = url;
            }
        }
    });
};

bindedDatepickers = [];

bindDatepicker = function() {
    var i;
    for (i in bindedDatepickers) {
        bindedDatepickers[i].destroy();
    }
    bindedDatepickers = [];
    return $('.datepicker__input').each(function() {
        var dateFormat, datepicker, pikaday, ref, time;
        datepicker = this;
        time = (ref = $(this).data('time')) != null ? ref : false;
        dateFormat = time ? 'MM/DD/YYYY hh:mm a' : 'MM/DD/YYYY';
        pikaday = new Pikaday({
            field: datepicker,
            format: dateFormat,
            showTime: time,
            use24hour: false,
            timeLabel: 'Time:',
            autoClose: !time,
            onSelect: function() {
                return $(datepicker).val(this.getMoment().format(dateFormat));
            }
        });
        bindedDatepickers.push(pikaday);
        return pikaday;
    });
};

bindArea = function() {
    var $area, $select, appendItem;
    $area = $('.area');
    $select = $('.area__select');
    appendItem = function($body, item) {
        $body.append("<div class='area__item' data-value='" + item.value + "'>" + item.text + "<span class='area__delete link icon_trash'></span></div>");
        return checkPopupScroll();
    };
    unbindEvents([$area, $select]);
    $area.each(function() {
        var $body, value;
        $body = $(this).find('.area__body');
        $select = $(this).find('.area__select');
        return value = $(this).data('value');
    });
    $select.change(function() {
        var $body, allowPush, areaValue, currentValue;
        $area = $(this).closest('.area');
        $body = $area.find('.area__body');
        areaValue = $area.data('value');
        currentValue = $(this).val();
        allowPush = true;
        if (!currentValue) {
            return false;
        }
        currentValue = typeof currentValue === 'string' ? parseInt(currentValue, 10) : currentValue;
        if (!areaValue) {
            $area.attr('data-value', JSON.stringify([currentValue]));
        } else {
            if (areaValue.indexOf(currentValue) < 0) {
                $area.attr('data-value', areaValue.push(currentValue));
            } else {
                allowPush = false;
            }
        }
        if (allowPush) {
            appendItem($body, {
                value: currentValue,
                text: $(this).find('option:selected').text()
            });
        }
        return $(this).val('');
    });
    return $area.on('click', '.area__delete', function() {
        var $item, areaValue, currentValue, index;
        $area = $(this).closest('.area');
        $item = $(this).parent();
        currentValue = $item.data('value');
        areaValue = $area.data('value');
        currentValue = typeof currentValue === 'string' ? parseInt(currentValue, 10) : currentValue;
        index = areaValue.indexOf(currentValue);
        if (index >= 0) {
            areaValue.splice(index, 1);
            $item.remove();
            $area.attr('data-value', areaValue);
            return checkPopupScroll();
        }
    });
};

confirmAction = function(successCallback, title, acceptButtonText) {
    var $button, $popup, activeClass;
    $popup = $('#popup_action-confirmation');
    $button = $('.confirmation__accept');
    activeClass = 'popup_active';
    title = title != null ? title : 'Are you sure?';
    acceptButtonText = acceptButtonText != null ? acceptButtonText : 'Save changes';
    $popup.find('.popup__title').text(title);
    $popup.find('.confirmation__accept').text(acceptButtonText);
    $popup.fadeIn().css('display', 'flex');
    setTimeout(function() {
        return $popup.addClass(activeClass);
    }, 100);
    return $button.unbind().click(function() {
        if (successCallback) {
            return successCallback();
        }
    });
};

bindTimepicker = function() {
    return $('.timepicker input.control__box').timepicker({
        timeFormat: 'h:mm p'
    });
};

bindAutocomplete = function() {
    var $project;
    $project = $('#select_item input.control__box');
    if ($project.length > 0) {
        $project.autocomplete({
            minLength: 1,
            source: document.projects,
            focus: function(event, ui) {
                $project.val(ui.item.label);
                return false;
            }
        });
        return $project.data("ui-autocomplete")._renderItem = function(ul, item) {
            var $img, $li;
            $li = $('<li>');
            $img = $('<img>');
            $img.attr({
                src: 'https://jqueryui.com/resources/demos/autocomplete/images/' + item.icon,
                alt: item.label
            });
            $li.attr('data-value', item.label);
            $li.append('<a href="#">');
            $li.find('a').append($img).append(item.label);
            return $li.appendTo(ul);
        };
    }
};

showLastAddNewOptionBtn = function(options) {
    options.each(function(i, e) {
        var addNewOptionBtn;
        addNewOptionBtn = $(e).find('.js-add-new-option');
        if (i === 0 || i === options.length - 1) {
            addNewOptionBtn.show();
            return;
        }
        addNewOptionBtn.hide();
    });
};

showLastAddNewOptionBtnGroup = function(options) {
    options.each(function(i, e) {
        var addNewOptionBtn;
        addNewOptionBtn = $(e).find('.js-add-new-group');
        if (i === 0 || i === options.length - 1) {
            addNewOptionBtn.show();
            return;
        }
        addNewOptionBtn.hide();
    });
};

$(document).on('click', '.js-delete-option', function(e) {
    var body, nameInput, options, priceInput, removableOption;
    body = $(this).parents('.js-dish-group');
    removableOption = $(this).parent('.js-dish-option');
    if (body.find('.js-dish-option').length === 2) {
        priceInput = removableOption.find('input[name=dish-option-price]');
        nameInput = removableOption.find('input[name=dish-option-name]');
        priceInput.val('');
        nameInput.val('');
        removableOption.attr('data-optionId', '');
        return;
    }
    removableOption.remove();
    options = body.find('.js-dish-option');
    showLastAddNewOptionBtn(options);
});

$(document).on('click', '.js-add-new-option', function(e) {
    var body, item, options;
    body = $(this).parents('.js-dish-group').find('.js-dish-options-body');
    options = body.find('.js-dish-option');
    item = $(options[0]).clone();
    item.show();
    body.append(item);
    options = body.find('.js-dish-option');
    showLastAddNewOptionBtn(options);
});

$(document).on('click', '.js-add-new-group', function(e) {
    var body, item, options;
    body = $(this).parents('.js-dish-options');
    options = body.find('.js-dish-group');
    item = $(options[0]).clone();
    item.show();
    body.append(item);
    options = body.find('.js-dish-group');
    showLastAddNewOptionBtnGroup(options);
});

$(document).on('click', '.js-delete-group', function(e) {
    var body, item, options, removableOption;
    body = $(this).parents('.js-dish-options');
    removableOption = $(this).parents('.js-dish-group');
    if (body.find('.js-dish-group').length === 2) {
        removableOption.remove();
        options = body.find('.js-dish-group');
        item = $(options[0]).clone();
        item.show();
        body.append(item);
        options = body.find('.js-dish-group');
        showLastAddNewOptionBtnGroup(options);
        return;
    }
    removableOption.remove();
    options = body.find('.js-dish-group');
    showLastAddNewOptionBtnGroup(options);
});

unbindEvents = function(elements) {
    var i, results;
    results = [];
    for (i in elements) {
        results.push(elements[i].unbind());
    }
    return results;
};